# MISSION: Main program interface.
# STATUS: Testing
# VERSION: 0.0.1
# NOTES: Works well.
# DATE: 2026-01-18 07:09:50
# FILE: __main__.py
# AUTHOR: Randall Nagy
#
from .core import mainloop, cli_main

cli_main()
