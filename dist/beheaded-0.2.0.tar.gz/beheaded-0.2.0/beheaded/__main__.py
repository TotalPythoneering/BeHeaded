# MISSION: Main program interface.
# STATUS: Testing
# VERSION: 0.0.2
# NOTES: Works well.
# DATE: 2026-01-18 07:09:50
# FILE: __main__.py
# AUTHOR: Randall Nagy
#
from .core import cli_main

cli_main()
