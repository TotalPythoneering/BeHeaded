from core import mainloop, cli_main

cli_main()
